import socket
import binascii
import os
from datetime import datetime
import struct
import pandas as pd
from datetime import datetime
import time

# 创建socket对象
socket_client = socket.socket()
# 连接到服务器
socket_client.connect(("192.168.0.9", 9201))

def bytes_to_float(byte_data, start_pos):
    # 取出指定范围的字节，并将其转换为浮点数
    return struct.unpack("!f", byte_data[start_pos : start_pos + 4])[0]

try:
    print("准备接收数据")
    # 确定数据存储路径
    # directory = "."
    # # directory = "D:/"
    # if not os.path.exists(directory):
    #     os.makedirs(directory)

    # 确定文件名
    # file_name = os.path.join(datetime.now().strftime("%Y_%m_%d %H_%M_%S_%f") + "IMUBD.txt")
    file_name = r"D:\0914gongyuan\IMU_BD2.csv"

    # 打开文件以写入数据
    with open(file_name, "w") as file:
        print(f"正在创建并写入文件: {file_name}")
        while True:
            # 接收数据头部
            # data_head = socket_client.recv(1024)

            # 接收实际数据
            data = socket_client.recv(1024)
            # print(data)
            accX = bytes_to_float(data, 22)
            accY = bytes_to_float(data, 26)
            accZ = bytes_to_float(data, 30)
            gryX = bytes_to_float(data, 37)
            gryY = bytes_to_float(data, 41)
            gryZ = bytes_to_float(data, 45)
            # print(accZ)
            if not data:
                print("没有接收到数据，可能客户端已经断开连接")
                break

            # 记录当前时间
            t1 = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
            # print(f"记录时间戳: {t1}")

            # 将数据写入文件
            file.write(t1 + "," + str(accX) + "," + str(accY) + "," + str(accZ) + "," + str(gryX) + "," + str(gryY) + "," + str(gryZ) + "\n")
            file.flush()
            # print("数据已写入文件")
finally:
    socket_client.close()

# import socket
# import binascii
# import os
# from datetime import datetime

# # 确定数据存储路径
# current_path = os.path.dirname(__file__)
# directory = "."
# if not directory:
#     directory = current_path
# if not os.path.exists(directory):
#     print(f"路径不存在，已自动创建目录: {directory}")
#     os.makedirs(directory)

# # 确定文件名
# file_name = os.path.join(directory, datetime.now().strftime("%Y_%m_%d %H_%M_%S_%f") + ".txt")
# print(f"{file_name}")
